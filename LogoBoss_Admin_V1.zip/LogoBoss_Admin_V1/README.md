# LogoBoss AI · Admin V1 (private test)

## What is ready
- Responsive admin dashboard, 13 agreed packages and prices, demo inquiries, customer view, status editing, CSV export.
- Optional Supabase email/password login with browser-session-only token and admin-only RLS policies.
- Standalone `schema.sql` to create a new admin table without modifying existing production orders.
- No Stripe Live or public order activation. Existing website remains unchanged.

## Try the demo
Open `index.html` using a local development server, e.g. `python3 -m http.server 8000` and navigate to http://localhost:8000. The dashboard works with fake data without connecting any service. Do not deploy this dashboard publicly before configuring authorization and additional security controls.

## Supabase setup (test environment only)
1. Create a separate test project or verify you have backups. Review `schema.sql`, then run it in Supabase SQL Editor.
2. Create an admin account in Supabase Authentication; keep public signup disabled, require strong password and MFA where supported.
3. In SQL Editor, add ONLY your own Auth user UUID to `lb_admin_users` as described in `schema.sql`.
4. Enter project URL, public publishable/anon key, email and password in Admin V1. Never use service_role or secret keys in HTML.
5. Test unauthorized reads and writes, and confirm only authorized admin can read and edit orders.

## Not connected yet
- Your public website currently POSTs to an existing `submit-order` Edge Function. This project does NOT inspect or alter that function. No orders from the public website will appear here until you safely map/insert validated submissions server-side into `lb_admin_orders`.
- Automatic emails, CRM and production Company OS modules, billing webhooks and backups require separate implementation and tests.
- Do not insert actual customer personal data into this test dashboard without a reviewed legal basis, access controls and retention policy.

## Before launch
Secure server-side order intake with validation and rate limits, bot protection, transactional email with verified domain, logs/monitoring, backups, privacy and legal documents, production QA, payment reconciliation. Wait for written immigration permission and business registration before commercial use.
