-- LogoBoss AI Admin V1: run manually in Supabase SQL Editor after review.
-- This creates a SEPARATE TEST admin order table; it does NOT replace existing orders.
create extension if not exists pgcrypto;
create table if not exists public.lb_admin_users (
 user_id uuid primary key references auth.users(id) on delete cascade,
 created_at timestamptz not null default now()
);
create table if not exists public.lb_admin_orders (
 id uuid primary key default gen_random_uuid(),
 customer_name text not null check(length(customer_name) between 1 and 200),
 company_name text not null default '' check(length(company_name)<=200),
 email text not null check(length(email) between 3 and 320),
 package_name text not null check(length(package_name) between 1 and 200),
 status text not null default 'new' check(status in ('new','reviewing','contacted','closed')),
 admin_note text not null default '' check(length(admin_note)<=2000),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create or replace function public.lb_set_updated_at() returns trigger language plpgsql as $$ begin new.updated_at=now(); return new; end $$;
drop trigger if exists lb_admin_orders_updated_at on public.lb_admin_orders;
create trigger lb_admin_orders_updated_at before update on public.lb_admin_orders for each row execute function public.lb_set_updated_at();
alter table public.lb_admin_users enable row level security;
alter table public.lb_admin_orders enable row level security;
revoke all on public.lb_admin_users from anon, authenticated;
revoke all on public.lb_admin_orders from anon, authenticated;
grant select on public.lb_admin_users to authenticated;
grant select,update on public.lb_admin_orders to authenticated;
drop policy if exists lb_admin_users_self on public.lb_admin_users;
create policy lb_admin_users_self on public.lb_admin_users for select to authenticated using (user_id=(select auth.uid()));
drop policy if exists lb_admin_orders_select on public.lb_admin_orders;
create policy lb_admin_orders_select on public.lb_admin_orders for select to authenticated using (exists(select 1 from public.lb_admin_users where user_id=(select auth.uid())));
drop policy if exists lb_admin_orders_update on public.lb_admin_orders;
create policy lb_admin_orders_update on public.lb_admin_orders for update to authenticated using (exists(select 1 from public.lb_admin_users where user_id=(select auth.uid()))) with check (exists(select 1 from public.lb_admin_users where user_id=(select auth.uid())));
-- Important: no INSERT policy for public/anon. Orders must be inserted ONLY by a validated
-- server-side Edge Function after rate limiting, spam protection, schema validation.
-- To authorize an existing Supabase Auth account, run privately in SQL Editor:
-- insert into public.lb_admin_users(user_id) values ('YOUR-EXISTING-AUTH-USER-UUID');
-- Do not put service_role keys or user UUIDs into public HTML.
